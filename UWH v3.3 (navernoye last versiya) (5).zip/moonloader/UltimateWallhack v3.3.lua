local ACTIVATE_COMMAND = 'wall'

local imgui = require('imgui')
local encoding = require 'encoding'
encoding.default = 'CP1251'
u8 = encoding.UTF8
local sampev = require 'lib.samp.events'

local window = imgui.ImBool(false)
local font = renderCreateFont("Arial", 9, 5)

--CHAMS  --�� ����� �� ������ �� ������ �������, ��� ����. ���� ���� ��� � ���� ���� �������� ��� ������� ��� ��� � ����� �������, ������� ��� ���� �������.
local lffi, ffi = pcall(require, 'ffi') assert(lffi, 'not found lib ffi')

local ffi = require("ffi")
ffi.cdef([[
    typedef unsigned long DWORD;

    struct d3ddeviceVTBL {
        void *QueryInterface;
        void *AddRef;
        void *Release;
        void *TestCooperativeLevel;
        void *GetAvailableTextureMem;
        void *EvictManagedResources;
        void *GetDirect3D;
        void *GetDeviceCaps;
        void *GetDisplayMode;
        void *GetCreationParameters;
        void *SetCursorProperties;
        void *SetCursorPosition;
        void *ShowCursor;
        void *CreateAdditionalSwapChain;
        void *GetSwapChain;
        void *GetNumberOfSwapChains;
        void *Reset;
        void *Present;
        void *GetBackBuffer;
        void *GetRasterStatus;
        void *SetDialogBoxMode;
        void *SetGammaRamp;
        void *GetGammaRamp;
        void *CreateTexture;
        void *CreateVolumeTexture;
        void *CreateCubeTexture;
        void *CreateVertexBuffer;
        void *CreateIndexBuffer;
        void *CreateRenderTarget;
        void *CreateDepthStencilSurface;
        void *UpdateSurface;
        void *UpdateTexture;
        void *GetRenderTargetData;
        void *GetFrontBufferData;
        void *StretchRect;
        void *ColorFill;
        void *CreateOffscreenPlainSurface;
        void *SetRenderTarget;
        void *GetRenderTarget;
        void *SetDepthStencilSurface;
        void *GetDepthStencilSurface;
        void *BeginScene;
        void *EndScene;
        void *Clear;
        void *SetTransform;
        void *GetTransform;
        void *MultiplyTransform;
        void *SetViewport;
        void *GetViewport;
        void *SetMaterial;
        void *GetMaterial;
        void *SetLight;
        void *GetLight;
        void *LightEnable;
        void *GetLightEnable;
        void *SetClipPlane;
        void *GetClipPlane;
        void *SetRenderState;
        void *GetRenderState;
        void *CreateStateBlock;
        void *BeginStateBlock;
        void *EndStateBlock;
        void *SetClipStatus;
        void *GetClipStatus;
        void *GetTexture;
        void *SetTexture;
        void *GetTextureStageState;
        void *SetTextureStageState;
        void *GetSamplerState;
        void *SetSamplerState;
        void *ValidateDevice;
        void *SetPaletteEntries;
        void *GetPaletteEntries;
        void *SetCurrentTexturePalette;
        void *GetCurrentTexturePalette;
        void *SetScissorRect;
        void *GetScissorRect;
        void *SetSoftwareVertexProcessing;
        void *GetSoftwareVertexProcessing;
        void *SetNPatchMode;
        void *GetNPatchMode;
        void *DrawPrimitive;
        void* DrawIndexedPrimitive;
        void *DrawPrimitiveUP;
        void *DrawIndexedPrimitiveUP;
        void *ProcessVertices;
        void *CreateVertexDeclaration;
        void *SetVertexDeclaration;
        void *GetVertexDeclaration;
        void *SetFVF;
        void *GetFVF;
        void *CreateVertexShader;
        void *SetVertexShader;
        void *GetVertexShader;
        void *SetVertexShaderConstantF;
        void *GetVertexShaderConstantF;
        void *SetVertexShaderConstantI;
        void *GetVertexShaderConstantI;
        void *SetVertexShaderConstantB;
        void *GetVertexShaderConstantB;
        void *SetStreamSource;
        void *GetStreamSource;
        void *SetStreamSourceFreq;
        void *GetStreamSourceFreq;
        void *SetIndices;
        void *GetIndices;
        void *CreatePixelShader;
        void *SetPixelShader;
        void *GetPixelShader;
        void *SetPixelShaderConstantF;
        void *GetPixelShaderConstantF;
        void *SetPixelShaderConstantI;
        void *GetPixelShaderConstantI;
        void *SetPixelShaderConstantB;
        void *GetPixelShaderConstantB;
        void *DrawRectPatch;
        void *DrawTriPatch;
        void *DeletePatch;
    };

    struct d3ddevice {
        struct d3ddeviceVTBL** vtbl;
    };
]])

local pDevice = ffi.cast("struct d3ddevice*", 0xC97C28)
local SetTextureStageState = ffi.cast("long(__stdcall*)(void*, unsigned long, unsigned long, unsigned long)", pDevice.vtbl[0].SetTextureStageState)
local GetTextureStageState = ffi.cast("long(__stdcall*)(void*, unsigned long, unsigned long, unsigned int*)", pDevice.vtbl[0].GetTextureStageState)

local dwConstant = ffi.new("unsigned int[1]")
local dwARG0 = ffi.new("unsigned int[1]")
local dwARG1 = ffi.new("unsigned int[1]")
local dwARG2 = ffi.new("unsigned int[1]")

local cast = ffi.cast("void(__thiscall*)(void*)", 0x59F180)
local ChamsQuery = {}
local changelog = [[
v1: 
    Release

v2: 
    + Bug Fix

v3: 
    + changeable bone thickness
    + interface rework
    + bugfix

v3.1:
    + CHAMS (test version)
    + added mode selector (always active / toggle / key press)
    + added peds opacity changer (Players > Other)
    + added buttons: Unload script, reload script
    + added textdraw id's

v3.2:
    + new interface
    + new ped box wallhack style (2D)
]]

--REQUIREMENTS
local imgui = require('imgui')
local encoding = require 'encoding'
encoding.default = 'CP1251'
u8 = encoding.UTF8
local ffi = require 'ffi'
local mem = require "memory"
local inicfg = require 'inicfg'

local text_changelog = imgui.ImBuffer(256)

local rkeys = require 'rkeys'
imgui.HotKey = require('imgui_addons').HotKey

local getBonePosition = ffi.cast("int (__thiscall*)(void*, float*, int, bool)", 0x5E4280)
local directIni = 'ImGuiWallhack.ini'
local ini = inicfg.load(inicfg.load({
hotkey = {
    mode = 0,
    key = '[49]',
    veh_mode = 0, --���� ������, ����� �����
    veh_key = '[50]',
},
other = {
    textdrawinfo = false,
    chatcmd = false,
    sfloadmessage = true,
    cheatcode = true,
},
wh = {
        head = true,
        larm = true, 
        rarm = true,
        lleg = true,
        rleg = true,
        body = true,
        name = true,
        ch_clistcolor = true,
        slider_boxsize = 3.0,
        slider_boxthickness = 1.0, 
        info_id = true,
        info_name = true,
        info_skin = true,
        info_lvl = true,
        info_armour = true,
        info_hp = true,
        slider_info_distance = 5.0,
        workonme = false,
        box = true,
        slider_bone_distance = 100.0,
        slider_bone_thickness = 2.0,
        ch_wh_ghost = true,
        slider_ghost_alpha = 255,
        slider_ghost_alpha_players = 255,
        ch_enableplayeralpha = false,
        chams_me = false,
        chams_players = false,
        ch_chams_clistcolor = false,
        box_mode = 1,
        bones_circles = true,
        tracers = true,
        tracers_thickness = 1,
        tracers_from = 1,
    },
veh = {
    box = true,
    info_id = true,
    info_modelid = true,
    info_modelname = true,
    info_driver = true,
    info_id = true,
    info_hp = true,
    workOnMyCar = false,
    slider_infodistance = 25.0,
    slider_boxdistance = 25.0,
    slider_boxsize = 3.0,
    slider_boxthickness = 1.0, 
    slider_bonethickness = 2.0,
    slider_bonedistance = 50,
},
color_wh_info_main = {
    r = 1.0,
    g = 1.0,
    b = 1.0,
    a = 1.0,
},
color_wh_info_second = {
    r = 1.0,
    g = 1.0,
    b = 1.0,
    a = 1.0,
},
chams_color_me = {
    r = 1.0,
    g = 1.0,
    b = 1.0,
    a = 1.0,
},
chams_color_players = {
    r = 1.0,
    g = 0.0,
    b = 0.0,
    a = 1.0,
}
}, directIni))
inicfg.save(ini, directIni)



local checkbox_placeholder = imgui.ImBool(false) --test

--OTHER
local td_info = imgui.ImBool(ini.other.textdrawinfo)


--PEDS WH

--CHAMS
local ch_chams_players = imgui.ImBool(ini.wh.chams_me)
local ch_chams_me = imgui.ImBool(ini.wh.chams_players)

    --colors
    local color_chams_info_main = imgui.ImFloat4(ini.color_wh_info_main.r, ini.color_wh_info_main.g, ini.color_wh_info_main.b, ini.color_wh_info_main.a)
    local color_chams_info_second = imgui.ImFloat4(ini.color_wh_info_second.r, ini.color_wh_info_second.g, ini.color_wh_info_second.b, ini.color_wh_info_second.a)

    local chams_color_me = imgui.ImFloat4(ini.chams_color_me.r, ini.chams_color_me.g, ini.chams_color_me.b, ini.chams_color_me.a)
    local chams_color_players = imgui.ImFloat4(ini.chams_color_players.r, ini.chams_color_players.g, ini.chams_color_players.b, ini.chams_color_players.a)
    
    local ch_chams_clistcolor = imgui.ImBool(ini.wh.ch_chams_clistcolor)
local window = imgui.ImBool(false)
local ch_head = imgui.ImBool(ini.wh.head)
local ch_body = imgui.ImBool(ini.wh.body)
local ch_larm = imgui.ImBool(ini.wh.larm)
local ch_rarm = imgui.ImBool(ini.wh.rarm)
local ch_lleg = imgui.ImBool(ini.wh.lleg)
local ch_rleg = imgui.ImBool(ini.wh.rleg)
local ch_name = imgui.ImBool(ini.wh.name)
local ch_clistcolor = imgui.ImBool(ini.wh.ch_clistcolor)
local ch_box = imgui.ImBool(ini.wh.box)
local ch_wh_workonme = imgui.ImBool(ini.wh.workonme)
local ch_wh_slider_boxthickness = imgui.ImFloat(ini.wh.slider_boxthickness) --25
local ch_wh_slider_boxsize = imgui.ImFloat(ini.wh.slider_boxsize) --25
local ch_enableplayeralpha = imgui.ImBool(ini.wh.ch_enableplayeralpha)
local ch_wh_ghost = imgui.ImBool(ini.wh.ch_wh_ghost) 
    --PED INFO
    local ch_wh_info_id = imgui.ImBool(ini.wh.info_id)
    local ch_wh_info_name = imgui.ImBool(ini.wh.info_name)
    local ch_wh_info_skin = imgui.ImBool(ini.wh.info_skin)
    local ch_wh_info_lvl = imgui.ImBool(ini.wh.info_lvl)
    local ch_wh_info_armour = imgui.ImBool(ini.wh.info_armour)
    local ch_wh_info_hp = imgui.ImBool(ini.wh.info_hp)
    local ch_wh_slider_infodistance = imgui.ImFloat(ini.wh.slider_info_distance) 
    local ch_wh_slider_bonedistance = imgui.ImFloat(ini.wh.slider_bone_distance) 
    local ch_wh_slider_bonethickness = imgui.ImFloat(ini.wh.slider_bone_thickness) 
    
    local ch_wh_ghost_alpha = imgui.ImFloat(ini.wh.slider_ghost_alpha) 
    local ch_wh_ghost_alpha_players = imgui.ImFloat(ini.wh.slider_ghost_alpha_players) 

--VEHS WH
local ch_vehbox = imgui.ImBool(ini.veh.box)
local ch_veh_id = imgui.ImBool(ini.veh.info_id)
local ch_veh_modelid = imgui.ImBool(ini.veh.info_modelid)
local ch_veh_modelname = imgui.ImBool(ini.veh.info_modelname)
local ch_veh_driver = imgui.ImBool(ini.veh.info_driver)
local ch_veh_hp = imgui.ImBool(ini.veh.info_hp)
local ch_veh_workonmy = imgui.ImBool(ini.veh.workOnMyCar)
    --VEH SLIDERS
    
    local ch_veh_slider_infodistance = imgui.ImFloat(ini.veh.slider_infodistance) --25
    local ch_veh_slider_boxdistance = imgui.ImFloat(ini.veh.slider_boxdistance) --25
    local ch_veh_slider_boxsize = imgui.ImFloat(ini.veh.slider_boxsize) --3
    local ch_veh_slider_boxthickness = imgui.ImFloat(ini.veh.slider_boxthickness) --1

    

local combo_mode = imgui.ImInt(ini.hotkey.mode)
local veh_combo_mode = imgui.ImInt(ini.hotkey.veh_mode)
local wh_mode_key = imgui.ImBuffer(256)

local vehwh_mode_key = imgui.ImBuffer(256)

local wh_main_chatcmdbool = imgui.ImBool(ini.other.chatcmd)


local menu = 1
local submenu = 1
local resX, resY = getScreenResolution()

local bones_circles = imgui.ImBool(ini.wh.bones_circles)

local mode_toggle_enabled = true

local wh_box_mode = imgui.ImInt(ini.wh.box_mode) --2d/3d box

local version = '3.3'

local tracer_thickness = imgui.ImInt(ini.wh.tracers_thickness)
local tracers = imgui.ImBool(ini.wh.tracers)
local tracer_from = imgui.ImInt(ini.wh.tracers_from)

local chams_mode = imgui.ImInt(1)
local other_sfloadmessage = imgui.ImBool(ini.other.sfloadmessage)

local cheatcode_active = imgui.ImBool(ini.other.cheatcode)

function main()
    while not isSampAvailable() do wait(200) end
    --while not sampIsLocalPlayerSpawned() do wait(500) end
    sampRegisterChatCommand('box', pedBox)
    result = sampfuncsRegisterConsoleCommand('wh',function() window.v = not window.v end)
    --sampRegisterChatCommand('chams', function() AddPlayerToChamsQuery(PLAYER_PED, 0xFFFF0000) end)
    --sampRegisterChatCommand('ghost', function() SetRwObjectAlpha(playerPed, 255) end)
    if result and ini.other.sfloadmessage then 
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} loaded!')
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} version: '..version..'!')
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} Author: Chapo!')
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} send {ff004d}"wh"{ffffff} in SAMPFUNCS console (~)!')
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} thanks to @Smeruxa, @FomikuS')
    else 
        --sampAddChatMessage('{ff0000}WH :: failed to register SF cmd!', -1) 
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} failed to register SF cmd!!')
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} failed to register SF cmd!!')
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} failed to register SF cmd!!')
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} failed to register SF cmd!!')
        sampfuncsLog('{ff004d}[Ultimate WallHack]:{ffffff} failed to register SF cmd!!')
    end
    if wh_main_chatcmdbool.v then sampRegisterChatCommand('wh', function() window.v = not window.v end) end
    imgui.Process = false
    window.v = false
    wh_mode_key.v = tostring(ini.hotkey.key)
    skin = imgui.CreateTextureFromFile('moonloader/resource/LWH/1.png')

   
    while true do
        wait(0)
        imgui.Process = window.v
        whmode = combo_mode.v
        --objectInfo()
        --SetRwObjectAlpha(playerPed, 150)
        
        if cheatcode_active.v then
            if isKeyDown(87) and wasKeyPressed(46) then window.v = not window.v end
        end

        if whmode == 0 then     --always active
            --chams()
            bonewh()
            vehInfo() 
            vehBox()
            pedInfo()
            tracer()
            nameRender()
            if wh_box_mode.v == 1 then
                pedBox()
            elseif wh_box_mode.v == 2 then
                pedBox2d()
            end
        elseif whmode == 1 then --toggle
            if wasKeyPressed(tonumber(wh_mode_key.v)) and not sampIsCursorActive() then
                mode_toggle_enabled = not mode_toggle_enabled
            end
        elseif whmode == 2 then --press
            --sampAddChatMessage('2', -1)
            if isKeyDown(tonumber(wh_mode_key.v)) and not sampIsCursorActive() then
                bonewh()
                vehBox()
                vehInfo() 
                pedInfo()
                tracer()
                nameRender()
                if wh_box_mode.v == 1 then
                    pedBox()
                elseif wh_box_mode.v == 2 then
                    pedBox2d()
                end
            end
        end
        
        if whmode == 1 and mode_toggle_enabled then
            bonewh()
            vehBox()
            vehInfo()
            pedInfo()
            tracer()
            nameRender()
            if wh_box_mode.v == 1 then
                pedBox()
            elseif wh_box_mode.v == 2 then
                pedBox2d()
            end
        end

        --pedBox2d()

        --SELF ALPHA
        if ch_enableplayeralpha.v then
            if ch_wh_workonme.v then
                SetRwObjectAlpha(PLAYER_PED, ch_wh_ghost_alpha.v)
            end
            playersAlpha()
        end
        if td_info.v then 
            for a = 0, 4096	do
                --if show_textdrawid then
                    if sampTextdrawIsExists(a) then
                        x, y = sampTextdrawGetPos(a) --we get it's position. value returns in game coords
                        x1, y1 = convertGameScreenCoordsToWindowScreenCoords(x, y) --so we convert it to screen cuz render needs screen coords
                        renderFontDrawText(font, '{ff004d}ID: {ffffff}'..a, x1 + 25, y1 + 15, 0xFFFFFFFF)
                    end
                --end
            end
        end
        --playersAlpha()

        --CHAMS
        if ch_chams_players.v then
            for k, i in ipairs(getAllChars()) do 
                if i ~= PLAYER_PED then
                    if ch_chams_clistcolor.v then
                        AddPlayerToChamsQuery(i, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(i))))
                    else
                        AddPlayerToChamsQuery(i, join_argb(chams_color_players.v[4] * 255, chams_color_players.v[1] * 255, chams_color_players.v[2] * 255, chams_color_players.v[3] * 255))
                    end
                end
            end
        else
            for k, i in ipairs(getAllChars()) do 
                if i ~= PLAYER_PED then
                    RemoveFromChamsQuery(i)
                end
            end
        end
        
        if ch_chams_me.v then AddPlayerToChamsQuery(PLAYER_PED, join_argb(chams_color_me.v[4] * 255, chams_color_me.v[1] * 255, chams_color_me.v[2] * 255, chams_color_me.v[3] * 255)) else RemoveFromChamsQuery(PLAYER_PED) end
        
        --NAME WH
        
    end
end

function imgui.OnDrawFrame()
    if window.v then
        imgui.SetNextWindowPos(imgui.ImVec2(resX / 2 - 165 / 2, resY / 2 - 280 / 2), imgui.Cond.FirstUseEver)
        imgui.SetNextWindowSize(imgui.ImVec2(500, 280), imgui.Cond.FirstUseEver) -- imgui.SetNextWindowSize(imgui.ImVec2(165, 280), imgui.Cond.FirstUseEver)
        imgui.Begin('Ultimate WallHack by chapo', window, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoScrollbar)

        --MENU SELECTOR
        --imgui.PushStyleColor(imgui.Col.Text, imgui.ImVec4(0, 0, 0, 1.00))
        imgui.SetCursorPos(imgui.ImVec2(5, 25))
        if imgui.Button('Players', imgui.ImVec2(100, 100)) then menu = 1 end
        imgui.SetCursorPos(imgui.ImVec2(5, 130))
        if imgui.Button('Other', imgui.ImVec2(100, 40)) then menu = 3 end
        imgui.SetCursorPos(imgui.ImVec2(5, 175))
        if imgui.Button('Vehicles', imgui.ImVec2(100, 100)) then menu = 2 end
        --imgui.PopStyleColor()
        

        if imgui.BeginPopupModal(u8'Other menu', window, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize) then
            imgui.SetWindowSize(imgui.ImVec2(300, 100))

            if imgui.Button('Unload Script', imgui.ImVec2(140, 25)) then thisScript():unload() end
            --imgui.SameLine()
            if imgui.Button('Reload Script', imgui.ImVec2(140, 25)) then thisScript():reload() end
            if imgui.Button('Delete Script', imgui.ImVec2(140, 25)) then 
                imgui.Text('Text')

                imgui.OpenPopup('deleteconfirm')

                
                
            end

            
            imgui.EndPopup()
        end

       

        
        --os.remove(thisScript().path)

        imgui.SetCursorPos(imgui.ImVec2(110, 24))
        --imgui.SameLine()
        imgui.BeginChild('cha�', imgui.ImVec2(385, 253), true, imgui.WindowFlags.NoScrollbar)
        --wh
        if menu == 1 then
            imgui.SetCursorPos(imgui.ImVec2(5, 5))
            if imgui.Button('Bones', imgui.ImVec2(50, 35)) then submenu = 1 end
            imgui.SetCursorPos(imgui.ImVec2(60, 5))
            if imgui.Button('Box', imgui.ImVec2(50, 35)) then submenu = 3 end
            imgui.SetCursorPos(imgui.ImVec2(115, 5))
            if imgui.Button('Chams', imgui.ImVec2(50, 35)) then submenu = 4 end
            imgui.SetCursorPos(imgui.ImVec2(170, 5))
            if imgui.Button('Tracers', imgui.ImVec2(50, 35)) then submenu = 5 end
            imgui.SetCursorPos(imgui.ImVec2(225, 5))
            if imgui.Button('Info', imgui.ImVec2(50, 35)) then submenu = 2 end
            
           -- imgui.SetCursorPos(imgui.ImVec2(252, 5))
            --if imgui.Button('Info', imgui.ImVec2(123, 35)) then submenu = 3 end
           -- i--mgui.Checkbox('Show Nicknames', checkbox_placeholder)

            --SUB 1
            if submenu == 1 then
                --imgui.BeginChild('sad', imgui.ImVec2(375, 245), true)
                plusposx = 225
                plusposy = - 30

                imgui.SetCursorPos(imgui.ImVec2(5, 40))
           
                if imgui.Checkbox('Show Name + ID', ch_name) then
                    --nameTag(ch_name.v)
                end

                imgui.SameLine()
                imgui.Checkbox('Work On Me', ch_wh_workonme)
                --imgui.NewLine()
                imgui.PushItemWidth(180)
                


                imgui.NewLine()
                imgui.Text('Bone WH')
                --imgui.NewLine()
                --imgui.PushItemWidth(180)
               -- imgui.SliderFloat('Bone Distance', ch_wh_slider_bonedistance, 1, 500)
               imgui.NewLine()

                imgui.Text('Bone Thickness')
                imgui.SliderFloat('###Bone Thickness', ch_wh_slider_bonethickness, 0.1, 5)
                imgui.PopItemWidth()

                imgui.NewLine()
                imgui.Text('Bones: ')

                if imgui.Button('All on', imgui.ImVec2(86, 20)) then
                    ch_head.v = true
                    ch_body.v = true
                    ch_larm.v = true
                    ch_rarm.v = true
                    ch_lleg.v = true
                    ch_rleg.v = true
                    --ch_name.v = true
                    save()
                end
                imgui.SameLine()
                if imgui.Button('All off', imgui.ImVec2(86, 20)) then
                    ch_head.v = false
                    ch_body.v = false
                    ch_larm.v = false
                    ch_rarm.v = false
                    ch_lleg.v = false
                    ch_rleg.v = false
                    --ch_name.v = false
                    save()
                end
                imgui.SetCursorPos(imgui.ImVec2(8 + plusposx, 25 + plusposy))
                imgui.Image(skin, imgui.ImVec2(150, 250))

                --imgui.Checkbox('bones_circles', bones_circles)

                imgui.NewLine()
                --local ch_wh_slider_bonedistance = imgui.ImFloat(ini.wh.slider_bone_distance) 
                --local ch_wh_slider_bonethickness = imgui.ImFloat(ini.wh.slider_bonethickness) 

                

                --head
                imgui.SetCursorPos(imgui.ImVec2(74 + plusposx, 45 + plusposy))
                if imgui.Checkbox('###gfggfcghjghjcfd', ch_head) then save() end

                --left arm
                imgui.SetCursorPos(imgui.ImVec2(17 + plusposx, 125 + plusposy))
                if imgui.Checkbox('###e5rg', ch_larm) then save() end

                --right arm
                imgui.SetCursorPos(imgui.ImVec2(125 + plusposx, 125 + plusposy))
                if imgui.Checkbox('###yjyj', ch_rarm) then save() end

                --body
                imgui.SetCursorPos(imgui.ImVec2(74 + plusposx, 125 + plusposy))
                if imgui.Checkbox('###sdfe', ch_body) then save() end

                --left leg
                imgui.SetCursorPos(imgui.ImVec2(54 + plusposx, 185 + plusposy))
                if imgui.Checkbox('###123', ch_lleg) then save() end
 
                --right leg
                imgui.SetCursorPos(imgui.ImVec2(87 + plusposx, 185 + plusposy))
                if imgui.Checkbox('###rl', ch_rleg) then save() end

                

                imgui.NewLine()
                

                --imgui.EndChild()---------------------------------------------------


            elseif submenu == 2 then 

                --imgui.Text('Chams')
                --imgui.SameLine()
                --imgui.TextQuestion('by KiN4StAt')
                --imgui.Checkbox('Enable chams', checkbox_placeholder)

                --imgui.ColorEdit4(,float col[4],ImGuiColorEditFlags flags = 0)

                --if imgui.ColorEdit4("Chams Color", color_chams_info_main) then 
                --local chams_color_me = imgui.ImFloat4(ini.chams_color_me.r, ini.chams_color_me.g, ini.chams_color_me.b, ini.chams_color_me.a)
                --local chams_color_players = imgui.ImFloat4(ini.chams_color_players.r, ini.chams_color_players.g, ini.chams_color_players.b, ini.chams_color_players.a)
                --end

                imgui.Text('Players INFO')
                imgui.SetCursorPos(imgui.ImVec2(5, 55))
                if imgui.Checkbox('Show ID', ch_wh_info_id) then save() end
                imgui.SetCursorPos(imgui.ImVec2(125, 55))
                if imgui.Checkbox('Show LVL', ch_wh_info_lvl) then save() end
                
                imgui.SetCursorPos(imgui.ImVec2(5, 75))
                if imgui.Checkbox('Show Skin ID', ch_wh_info_skin) then save() end
                imgui.SetCursorPos(imgui.ImVec2(125, 75))
                if imgui.Checkbox('Show HP', ch_wh_info_hp) then save() end
               
                imgui.SetCursorPos(imgui.ImVec2(5, 95))
                if imgui.Checkbox('Show Armour', ch_wh_info_armour) then save() end

                if imgui.Button('All on', imgui.ImVec2(86, 20)) then
                    ch_wh_info_id.v = true
                    ch_wh_info_lvl.v = true
                    ch_wh_info_skin.v = true
                    ch_wh_info_hp.v = true
                    ch_wh_info_armour.v = true
                    save()
                end
                imgui.SameLine()
                if imgui.Button('All off', imgui.ImVec2(86, 20)) then
                    ch_wh_info_id.v = false
                    ch_wh_info_lvl.v = false
                    ch_wh_info_skin.v = false
                    ch_wh_info_hp.v = false
                    ch_wh_info_armour.v = false
                    save()
                end

                imgui.PushItemWidth(375)
                imgui.TextColoredRGB('Info Distance')
                
                imgui.SliderFloat('###Info Distance', ch_wh_slider_infodistance, 1, 500)
                imgui.PopItemWidth()
                
                
            elseif submenu == 3 then --box
                imgui.Checkbox('Box Wallhack', ch_box)
                imgui.NewLine()
                imgui.RadioButton('3D' , wh_box_mode, 1)
                imgui.TextQuestion('by Smeruxa')
                imgui.SameLine()
                imgui.RadioButton('2D' , wh_box_mode, 2)
                imgui.SameLine()
                imgui.TextQuestion('by FomikuS')

                imgui.PushItemWidth(375)
               
                imgui.Text('Box Size')
                imgui.SliderFloat('Box Size', ch_wh_slider_boxsize, 0.1, 5)

                imgui.NewLine()

                imgui.Text('Box Thickness')
                
                imgui.SliderFloat('###Box Thickness', ch_wh_slider_boxthickness, 0.1, 10)
                imgui.PopItemWidth()
            elseif submenu == 4 then --chams
                imgui.PushItemWidth(375)
                --NOTE
                imgui.Text('CHAMS')
                imgui.SameLine()
                imgui.TextQuestion('by KiN4StAt (BETA)')
                --
                
                imgui.Checkbox('Chams on PLAYER_PED', ch_chams_me)
                imgui.SameLine()
                
                imgui.Text('| PED Color: ')
                imgui.SameLine()
                if imgui.ColorEdit4("###| PED Chams", chams_color_me, imgui.ColorEditFlags.NoInputs) then 
                --local chams_color_me = imgui.ImFloat4(ini.chams_color_me.r, ini.chams_color_me.g, ini.chams_color_me.b, ini.chams_color_me.a)
                --local chams_color_players = imgui.ImFloat4(ini.chams_color_players.r, ini.chams_color_players.g, ini.chams_color_players.b, ini.chams_color_players.a)
                end

                if imgui.Checkbox('Chams on Other Players', ch_chams_players) then
                    if not ch_chams_players.v then 
                        --thisScript():reload()
                        
                    end
                end
                imgui.SameLine()
                --
                imgui.Text('| Chams Color: ')
                imgui.SameLine()
                if imgui.ColorEdit4("###Players Chams", chams_color_players, imgui.ColorEditFlags.NoInputs) then 
                    --local chams_color_me = imgui.ImFloat4(ini.chams_color_me.r, ini.chams_color_me.g, ini.chams_color_me.b, ini.chams_color_me.a)
                    --local chams_color_players = imgui.ImFloat4(ini.chams_color_players.r, ini.chams_color_players.g, ini.chams_color_players.b, ini.chams_color_players.a)
                end
                imgui.Checkbox('Clist color', ch_chams_clistcolor)

                imgui.NewLine()
                

                
                imgui.Text('Players Alpha')
                imgui.Checkbox('Enable Players Alpha', ch_enableplayeralpha)
                --imgui.Checkbox('Enable PED Alpha', ch_wh_ghost)
                imgui.TextQuestion(u8'������ ������� ����� �������� ���� �������')
                imgui.NewLine()

                imgui.Text('PED Alpha')
                --imgui.SliderFloat('PED Alpha', ch_wh_ghost_alpha, 1, 255)
                
                imgui.Text('Players Alpha')
                imgui.SliderFloat('Players Alpha', ch_wh_ghost_alpha_players, 1, 255)

                imgui.PopItemWidth()
                --local ch_wh_ghost_alpha = imgui.ImFloat(ini.wh.slider_ghost_alpha) 
            elseif submenu == 5 then
                imgui.PushItemWidth(375)
                imgui.Checkbox('Show Tracers', tracers)
                imgui.NewLine()
                imgui.Text('Tracer Thickness')
                imgui.SliderInt('###tracer_thickness', tracer_thickness, 1, 10)
                imgui.NewLine()
                imgui.Text('Tracer From')
                imgui.Combo('###Tracer From', tracer_from, {'Screen Top', 'Screen Bottom', 'From PLAYER_PED'}, 3)
                imgui.PopItemWidth()
            end

            --[[

local color_wh_info_main = imgui.ImFloat4(ini.color_wh_info_main.r, ini.color_wh_info_main.g, ini.color_wh_info_main.b, ini.color_wh_info_main.a)
    local color_wh_info_second = imgui.ImFloat4(ini.color_wh_info_second.r, ini.color_wh_info_second.g, ini.color_wh_info_second.b, ini.color_wh_info_second.a)

            ]]
        end
       
        
        --chat
        --imgui.SetCursorPos(imgui.ImVec2(110, 22))
        
        if menu == 2 then
            imgui.Checkbox('veh box', ch_vehbox)
            imgui.SameLine()
            imgui.Checkbox('Work on my car', ch_veh_workonmy)
            imgui.SliderFloat('Box Distance', ch_veh_slider_boxdistance, 1, 500)
            imgui.SliderFloat('Box Size', ch_veh_slider_boxsize, 0.1, 5)
            imgui.SliderFloat('Box Thickness', ch_veh_slider_boxthickness, 0.1, 10)
           

            
            imgui.BeginChild('vehinfo', imgui.ImVec2(375, 160), true)

            imgui.Checkbox(' Show Car ID ', ch_veh_id)
            imgui.Checkbox(' Show Car Model ID ', ch_veh_modelid)
            imgui.Checkbox(' Show Car Model Name ', ch_veh_modelname)
            imgui.Checkbox(' Show Car Driver ', ch_veh_driver)
            if imgui.Button('All on', imgui.ImVec2(86, 20)) then
                ch_veh_id.v = true
                ch_veh_modelid.v = true
                ch_veh_modelname.v = true
                ch_veh_driver.v = true
                save()
            end
            imgui.SameLine()
            if imgui.Button('All off', imgui.ImVec2(86, 20)) then
                ch_veh_id.v = false
                ch_veh_modelid.v = false
                ch_veh_modelname.v = false
                ch_veh_driver.v = false
                save()
            end
            
            imgui.SliderFloat('Info Distance', ch_veh_slider_infodistance, 1, 500)

            --imgui.SliderFloat('X', ch_veh_slider_infoX, -1000, 1000)
            --imgui.SliderFloat('Y', ch_veh_slider_infoY, -5, 5)
            --imgui.SliderFloat('Z', ch_veh_slider_infoZ, -1000, 1000)
            imgui.EndChild()
        end

        if menu == 3 then
            imgui.SetCursorPosX(300)
            if imgui.Button('Unload Script', imgui.ImVec2(85, 25)) then 
                imgui.ShowCursor = false
                thisScript():unload() 
            end
            --imgui.NewLine()
            imgui.SetCursorPosX(300)
            if imgui.Button('Reload Script', imgui.ImVec2(85, 25)) then 
                thisScript():reload() 
                imgui.ShowCursor = false
            end
            
            imgui.SetCursorPosX(300)
            if imgui.Button('Thanks to', imgui.ImVec2(85, 25)) then
                imgui.OpenPopup('Thanks to')
            end
            --imgui.SameLine()
            imgui.SetCursorPosX(300)

            if imgui.Button('Changelog', imgui.ImVec2(85, 25)) then imgui.OpenPopup('ChangeLog') end
            --changelog
            if imgui.BeginPopupModal(u8'ChangeLog', window, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoTitleBar) then
                imgui.SetWindowSize(imgui.ImVec2(293, 300))
                
                --imgui.Text(u8(changelog))
                text_changelog.v  = u8(changelog)
                imgui.InputTextMultiline('####sdaf', text_changelog, imgui.ImVec2(283, 230))
                imgui.NewLine()
                --imgui.SameLine()
                if imgui.Button('Close', imgui.ImVec2(283, 25)) then imgui.CloseCurrentPopup() end
                
                imgui.EndPopup()
            end
            imgui.SetCursorPosY(5)
            imgui.Text('Activation')
            imgui.SetCursorPosY(25)
            imgui.Text('Mode')
            imgui.Combo(u8'###Mode', combo_mode, {'Always active', 'Toggle (button)', 'Press'}, 3)

            if combo_mode.v == 1 then
                imgui.PushItemWidth(80)
                imgui.InputText('Key ID', wh_mode_key)
                imgui.PopItemWidth()
                imgui.SameLine()
                if imgui.Button('Get ID', imgui.ImVec2(45, 18)) then os.execute('explorer https://css-tricks.com/snippets/javascript/javascript-keycodes/') end
            elseif combo_mode.v == 2 then
                imgui.PushItemWidth(80)
                imgui.InputText('Key ID', wh_mode_key)
                imgui.PopItemWidth()
                imgui.SameLine()
                if imgui.Button('Get ID', imgui.ImVec2(45, 18)) then os.execute('explorer https://css-tricks.com/snippets/javascript/javascript-keycodes/') end
            end

            --imgui.SetCursorPosY()
            if combo_mode.v ~= 0 then
                imgui.SetCursorPosY(85)
            else
                imgui.SetCursorPosY(65)
            end
            if imgui.Checkbox('Open menu with chat command', wh_main_chatcmdbool) then
                if wh_main_chatcmdbool.v then
                    sampRegisterChatCommand('wh', function() window.v = not window.v end)
                else
                    if sampIsChatCommandDefined('wh') then sampUnregisterChatCommand('wh') end
                end
            end
            imgui.SameLine()
            imgui.TextQuestion('/wh')

           
            if combo_mode.v ~= 0 then
                imgui.SetCursorPosY(105)
            else
                imgui.SetCursorPosY(85)
            end
            
            imgui.Checkbox('Open menu with Cheat-Code', cheatcode_active)
            imgui.SameLine()
            imgui.TextQuestion('W + Delete')



            imgui.SetCursorPosY(150)
            imgui.Checkbox('Show load message in SAMPFUNCS console', other_sfloadmessage)

            imgui.SetCursorPosY(170)
            imgui.Checkbox('Show TextDraws ID', td_info)

                      
            

            imgui.NewLine()
            

            
            if imgui.BeginPopupModal(u8'Thanks to', window, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize + imgui.WindowFlags.NoTitleBar) then
                imgui.SetWindowSize(imgui.ImVec2(293, 100))
                
                imgui.TextColored(imgui.ImVec4(1, 1, 1, 1), '@Smeruxa - Box Wallhack (3D)')
                imgui.TextColored(imgui.ImVec4(1, 1, 1, 1), '@FomikuS - Box Wallhack (2D)')

                imgui.SetCursorPosY(70)
                if imgui.Button('Close', imgui.ImVec2(283, 25)) then imgui.CloseCurrentPopup() end
                
                imgui.EndPopup()
            end
            
            
            
           
            
            
            imgui.SetCursorPosY(200)
            imgui.Text('Author: Chapo')
            imgui.Text('Version: '..version)
            imgui.Link("https://www.blast.hk/threads/80896/")
            if imgui.BeginPopupModal(u8'deleteconfirm', window, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar + imgui.WindowFlags.NoResize) then
                imgui.SetWindowSize(imgui.ImVec2(293, 75))
    
                if imgui.Button('Yes, delete script', imgui.ImVec2(280, 25)) then 
                    sampAddChatMessage('os.remove(thisScript().path)', -1) 
                    imgui.ShowCursor = false
                end --os.remove(thisScript().path)
                --imgui.SameLine()
                if imgui.Button('Cancel', imgui.ImVec2(280, 25)) then imgui.CloseCurrentPopup() end
                
                imgui.EndPopup()
            end
        end
        --if td_info.v then textdrawInfo() end
        imgui.EndChild()

        imgui.End()
    end

    
end

function textdrawInfo()
    lua_thread.create(function()
        for i = 1, 4096 do
            result = sampTextdrawIsExists(i)
            if result then
                x, y = sampTextdrawGetPos(i)
                x1, y1 = convertGameScreenCoordsToWindowScreenCoords(x, y)
                string = sampTextdrawGetString(i)
                style = sampTextdrawGetStyle(i)
                shadow, color = sampTextdrawGetShadowColor(i)
                outline, outlineColor = sampTextdrawGetOutlineColor(i)
                --samptextdrawget
               
                renderFontDrawText(font, 'textdraw '..i, x1, y1, 0xFFFFFFFF)
            end
        end
    end)
end

function objectInfo()
    lua_thread.create(function()
        for _, v in pairs(getAllObjects()) do
            --local asd = nil
            if sampGetObjectSampIdByHandle(v) ~= -1 then
                id = sampGetObjectSampIdByHandle(v)
            end
            if isObjectOnScreen(v) then
                local _, x, y, z = getObjectCoordinates(v)
                local x1, y1 = convert3DCoordsToScreen(x,y,z)
                local model = getObjectModel(v)
                local x2,y2,z2 = getCharCoordinates(PLAYER_PED)
                local x10, y10 = convert3DCoordsToScreen(x2,y2,z2)
                local distance = string.format("%.1f", getDistanceBetweenCoords3d(x, y, z, x2, y2, z2))
                
                renderFontDrawText(font, "Model ID: "..model.."; id = "..sampGetObjectSampIdByHandle(v).."Distance: "..distance, x1, y1, -1)
                    
                
            end
        end
    end)
end

--GHOST
function playersAlpha()
    lua_thread.create(function() 
        if ch_enableplayeralpha.v then
            for k, i in ipairs(getAllChars()) do 
                if i ~= PLAYER_PED then
                    SetRwObjectAlpha(i, ch_wh_ghost_alpha_players.v)
                end
            end
        end
    end)      
end

function vehInfo()--�������, �� ��� �����
    lua_thread.create(function() 
        if ch_veh_workonmy.v then 
            for i = 1, 2000 do
                result, carHandle = sampGetCarHandleBySampVehicleId(i)
                if result then
                    if isCarOnScreen(carHandle) then
                        carX, carY, carZ = getCarCoordinates(carHandle)
                        myX, myY, myZ = getCharCoordinates(PLAYER_PED)
                        distance = getDistanceBetweenCoords3d(carX, carY, carZ, myX, myY, myZ)
                        if distance <= ch_veh_slider_infodistance.v then
                            infoPosX, infoPosY = convert3DCoordsToScreen(carX, carY, carZ)
                            if ch_veh_id.v then id_text = '{ff004d}Car ID: {ffffff}'..i..'\n' else id_text = '' end
                            if ch_veh_modelid.v then modelid_text = '{ff004d}Car Model: {ffffff}'..getCarModel(carHandle)..'\n' else modelid_text = '' end
                            if ch_veh_modelname.v then modelname_text = '{ff004d}Car Model Name: {ffffff}'..getNameOfVehicleModel(getCarModel(carHandle))..'\n' else modelname_text = '' end
                            --if ch_veh_driver.v then driver_text = '{ff004d}Car Driver: {ffffff}'..sampGetPlayerNickname(select(2, sampGetPlayerIdByCharHandle(getDriverOfCar(carHandle))))..' ['..select(2, sampGetPlayerIdByCharHandle(getDriverOfCar(carHandle)))..']\n' else driver_text = '' end
                            if ch_veh_driver.v then driver_text = '{ff004d}Car Driver: {ffffff}'..select(2, sampGetPlayerIdByCharHandle(getDriverOfCar(carHandle)))..'\n' else driver_text = '' end
                            --if ch_veh_hp.v then hp_text = '{ff004d}Car HP: {ffffff}'..getCarHealth(storeCarCharIsInNoSave(PLAYER_PED))..'\n' else hp_text = '' end
                            renderFontDrawText(font, id_text..modelid_text..modelname_text..driver_text, infoPosX, infoPosY, 0xFFFFFFFF)
                        end
                    end
                end
            end        
        else
            for i = 1, 2000 do
                result, carHandle = sampGetCarHandleBySampVehicleId(i)
                mycarhandle = storeCarCharIsInNoSave(PLAYER_PED)
                if result then
                    if isCarOnScreen(carHandle) and carHandle ~= mycarhandle then
                        carX, carY, carZ = getCarCoordinates(carHandle)
                        myX, myY, myZ = getCharCoordinates(PLAYER_PED)
                        distance = getDistanceBetweenCoords3d(carX, carY, carZ, myX, myY, myZ)
                        if distance <= ch_veh_slider_infodistance.v then
                            infoPosX, infoPosY = convert3DCoordsToScreen(carX, carY, carZ)
                            if ch_veh_id.v then id_text = '{ff004d}Car ID: {ffffff}'..i..'\n' else id_text = '' end
                            if ch_veh_modelid.v then modelid_text = '{ff004d}Car Model: {ffffff}'..getCarModel(carHandle)..'\n' else modelid_text = '' end
                            if ch_veh_modelname.v then modelname_text = '{ff004d}Car Model Name: {ffffff}'..getNameOfVehicleModel(getCarModel(carHandle))..'\n' else modelname_text = '' end
                            --if ch_veh_driver.v then driver_text = '{ff004d}Car Driver: {ffffff}'..sampGetPlayerNickname(select(2, sampGetPlayerIdByCharHandle(getDriverOfCar(carHandle))))..' ['..select(2, sampGetPlayerIdByCharHandle(getDriverOfCar(carHandle)))..']\n' else driver_text = '' end
                            if ch_veh_driver.v then driver_text = '{ff004d}Car Driver: {ffffff}'..select(2, sampGetPlayerIdByCharHandle(getDriverOfCar(carHandle)))..'\n' else driver_text = '' end
                            --if ch_veh_hp.v then hp_text = '{ff004d}Car HP: {ffffff}'..getCarHealth(storeCarCharIsInNoSave(PLAYER_PED))..'\n' else hp_text = '' end
                            renderFontDrawText(font, id_text..modelid_text..modelname_text..driver_text, infoPosX, infoPosY, 0xFFFFFFFF)
                            
                            
                        end
                    end
                end
            end   
        end
    end)
end

function vehBox()
    lua_thread.create(function() 
        if ch_vehbox.v then
        if ch_veh_workonmy.v then 
            for k,v in ipairs(getAllVehicles()) do 
                if isCarOnScreen(v) then
                    carX, carY, carZ = getCarCoordinates(v)
                    myX, myY, myZ = getCharCoordinates(PLAYER_PED)
                    distance = getDistanceBetweenCoords3d(carX, carY, carZ, myX, myY, myZ)
                    if distance <= ch_veh_slider_boxdistance.v then
    
                    size = ch_veh_slider_boxsize.v
                    thickness = ch_veh_slider_boxthickness.v
                    
                    local pos = {getCarCoordinates(v)}
                    local pos_1 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size)}
                    local pos_2 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] - size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_3 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] + size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_3[1], pos_3[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_4 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] + size)}
                    renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_5 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size)}
                    renderDrawLine(pos_4[1], pos_4[2], pos_5[1], pos_5[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_1 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size)}
                    local pos_2 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_3 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] - size)}
                    local pos_4 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] - size)}
                    renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] + size)}
                    local pos_6 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] + size)}
                    renderDrawLine(pos_5[1], pos_5[2], pos_6[1], pos_6[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] + size)}
                    local pos_6 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] + size)}
                    renderDrawLine(pos_5[1], pos_5[2], pos_6[1], pos_6[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_1 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size)}
                    local pos_2 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] - size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_3 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] + size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_3[1], pos_3[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_4 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] + size)}
                    renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size)}
                    renderDrawLine(pos_4[1], pos_4[2], pos_5[1], pos_5[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    end
                end
            end
        else
            for k,v in ipairs(getAllVehicles()) do 
                if isCarOnScreen(v) and storeCarCharIsInNoSave(PLAYER_PED) ~= v then
                    carX, carY, carZ = getCarCoordinates(v)
                    myX, myY, myZ = getCharCoordinates(PLAYER_PED)
                    distance = getDistanceBetweenCoords3d(carX, carY, carZ, myX, myY, myZ)
                    if distance <= ch_veh_slider_boxdistance.v then
    
                    size = ch_veh_slider_boxsize.v
                    thickness = ch_veh_slider_boxthickness.v
                    
                    local pos = {getCarCoordinates(v)}
                    local pos_1 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size)}
                    local pos_2 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] - size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_3 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] + size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_3[1], pos_3[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_4 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] + size)}
                    renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_5 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size)}
                    renderDrawLine(pos_4[1], pos_4[2], pos_5[1], pos_5[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_1 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size)}
                    local pos_2 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_3 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] - size)}
                    local pos_4 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] - size)}
                    renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] + size)}
                    local pos_6 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] + size)}
                    renderDrawLine(pos_5[1], pos_5[2], pos_6[1], pos_6[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] + size)}
                    local pos_6 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] + size)}
                    renderDrawLine(pos_5[1], pos_5[2], pos_6[1], pos_6[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_1 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size)}
                    local pos_2 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] - size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_3 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] + size)}
                    renderDrawLine(pos_2[1], pos_2[2], pos_3[1], pos_3[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_4 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] + size)}
                    renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size)}
                    renderDrawLine(pos_4[1], pos_4[2], pos_5[1], pos_5[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    end
                end
            end
        end
        end
    end) 
end

--[[
function chams()
    for k,v in ipairs(getAllChars()) do 
        x, y, z = getCharCoordinates(v)
        myX, myY, myZ = getCharCoordinates(PLAYER_PED)
        distance = getDistanceBetweenCoords3d(x, y, z, myX, myY, myZ)
        if distance <= 25 then
            
            AddPlayerToChamsQuery(v, 0xFFFF0000)
            RemoveFromChamsQuery(v)
        else
            RemoveFromChamsQuery(v)
        end
    end
end
]]
function mode_toggle()
	sampAddChatMessage('tgl', -1)
end

function mode_press()
	sampAddChatMessage('prs', -1)
end

function pedBox2d() --� ��� ����� 2� ������ ������
    lua_thread.create(function()
        for k,v in ipairs(getAllChars()) do
            if isCharOnScreen(v) then  
                if ch_box.v  then
                if ch_wh_workonme.v then   
                    
                    size = 1
                    size_vertical = 0.3
                    thickness = ch_wh_slider_boxthickness.v
                    --type 1 (by Head)
                    local head_pos = {getBodyPartCoordinates(8, v)}
                    local leg_pos = {getBodyPartCoordinates(44, v)}
                    local pos_1 = {convert3DCoordsToScreen(head_pos[1], head_pos[2], head_pos[3] + 0.2)}
                    local pos_2 = {convert3DCoordsToScreen(head_pos[1], head_pos[2], head_pos[3] - (head_pos[3] - leg_pos[3]) - 0.1)}
                    a = boxWidth(pos_1[2], pos_2[2])
                    local box_corners = {
                        {pos_1[1] - a, pos_1[2]},
                        {pos_1[1] + a, pos_1[2]},
                        {pos_2[1] - a, pos_2[2]},
                        {pos_2[1] + a, pos_2[2]}
                    }
                    renderDrawLine(box_corners[1][1], box_corners[1][2], box_corners[2][1], box_corners[2][2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    renderDrawLine(box_corners[3][1], box_corners[3][2], box_corners[4][1], box_corners[4][2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    renderDrawLine(box_corners[1][1], box_corners[1][2], box_corners[3][1], box_corners[3][2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    renderDrawLine(box_corners[2][1], box_corners[2][2], box_corners[4][1], box_corners[4][2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                else
                    if v ~= PLAYER_PED then
                        size = 1
                        size_vertical = 0.3
                        thickness = 1
                        --type 1 (by Head)
                        local head_pos = {getBodyPartCoordinates(8, v)}
                        local leg_pos = {getBodyPartCoordinates(44, v)}
                        local pos_1 = {convert3DCoordsToScreen(head_pos[1], head_pos[2], head_pos[3] + 0.2)}
                        local pos_2 = {convert3DCoordsToScreen(head_pos[1], head_pos[2], head_pos[3] - (head_pos[3] - leg_pos[3]) - 0.1)}
                        a = boxWidth(pos_1[2], pos_2[2])
                        local box_corners = {
                            {pos_1[1] - a, pos_1[2]},
                            {pos_1[1] + a, pos_1[2]},
                            {pos_2[1] - a, pos_2[2]},
                            {pos_2[1] + a, pos_2[2]}
                        }
                        renderDrawLine(box_corners[1][1], box_corners[1][2], box_corners[2][1], box_corners[2][2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                        renderDrawLine(box_corners[3][1], box_corners[3][2], box_corners[4][1], box_corners[4][2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                        renderDrawLine(box_corners[1][1], box_corners[1][2], box_corners[3][1], box_corners[3][2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                        renderDrawLine(box_corners[2][1], box_corners[2][2], box_corners[4][1], box_corners[4][2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                    end
                end
            end
            end
        end
    end)
end
function boxWidth(a,b)
    h = b - a
    ang = (7 * math.pi)/180
    x = (h * math.tan(ang)) * 2
    return x
end

function tracer()
    lua_thread.create(function() 
        if tracers.v then
            for k,v in ipairs(getAllChars()) do 
               if isCharOnScreen(v) and v ~= PLAYER_PED then
                   x, y, z = getCharCoordinates(v)
                   wposX, wposY = convert3DCoordsToScreen(x, y, z - 1)
                   _, id = sampGetPlayerIdByCharHandle(v)
                   color = sampGetPlayerColor(id)
                   if tracer_from.v == 0 then
                       renderDrawLine(resX / 2 , 0, wposX, wposY, tracer_thickness.v, color)
                   elseif tracer_from.v == 1 then
                       renderDrawLine(resX / 2 , resY, wposX, wposY, tracer_thickness.v, color)
                   elseif tracer_from.v == 2 then
                    myX, myY, myZ = getCharCoordinates(PLAYER_PED)
                    meSX, meSY = convert3DCoordsToScreen(myX, myY, myZ - 1)
                    renderDrawLine(meSX, meSY, wposX, wposY, tracer_thickness.v, color)
                   end
               end
            end
        end
    end)
end

function pedBox()
    lua_thread.create(function() 
        for k,v in ipairs(getAllChars()) do 
            if isCharOnScreen(v) then
                if ch_box.v then
                    if wh_box_mode.v == 1 then
                        if ch_wh_workonme.v then
                            size = ch_wh_slider_boxsize.v
                            size_vertical = 0.7
                            thickness = ch_wh_slider_boxthickness.v
                            local pos = {getCharCoordinates(v)}
                            local pos_1 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size_vertical)}
                            local pos_2 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] - size_vertical)}
                            renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_3 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] + size_vertical)}
                            renderDrawLine(pos_2[1], pos_2[2], pos_3[1], pos_3[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_4 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] + size_vertical)}
                            renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_5 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size_vertical)}
                            renderDrawLine(pos_4[1], pos_4[2], pos_5[1], pos_5[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_1 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size_vertical)}
                            local pos_2 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size_vertical)}
                            renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_3 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] - size_vertical)}
                            local pos_4 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] - size_vertical)}
                            renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] + size_vertical)}
                            local pos_6 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] + size_vertical)}
                            renderDrawLine(pos_5[1], pos_5[2], pos_6[1], pos_6[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] + size_vertical)}
                            local pos_6 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] + size_vertical)}
                            renderDrawLine(pos_5[1], pos_5[2], pos_6[1], pos_6[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_1 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size_vertical)}
                            local pos_2 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] - size_vertical)}
                            renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_3 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] + size_vertical)}
                            renderDrawLine(pos_2[1], pos_2[2], pos_3[1], pos_3[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_4 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] + size_vertical)}
                            renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size_vertical)}
                            renderDrawLine(pos_4[1], pos_4[2], pos_5[1], pos_5[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                            else
                                if v ~= PLAYER_PED then
                                    size = ch_wh_slider_boxsize.v
                                    size_vertical = 0.7
                                    thickness = ch_wh_slider_boxthickness.v
                                    local pos = {getCharCoordinates(v)}
                                    local pos_1 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size_vertical)}
                                    local pos_2 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] - size_vertical)}
                                    renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_3 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] + size_vertical)}
                                    renderDrawLine(pos_2[1], pos_2[2], pos_3[1], pos_3[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_4 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] + size_vertical)}
                                    renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_5 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size_vertical)}
                                    renderDrawLine(pos_4[1], pos_4[2], pos_5[1], pos_5[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_1 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size_vertical)}
                                    local pos_2 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] - size_vertical)}
                                    renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_3 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] - size_vertical)}
                                    local pos_4 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] - size_vertical)}
                                    renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] + size_vertical)}
                                    local pos_6 = {convert3DCoordsToScreen(pos[1] + size, pos[2] + size, pos[3] + size_vertical)}
                                    renderDrawLine(pos_5[1], pos_5[2], pos_6[1], pos_6[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] + size_vertical)}
                                    local pos_6 = {convert3DCoordsToScreen(pos[1] + size, pos[2] - size, pos[3] + size_vertical)}
                                    renderDrawLine(pos_5[1], pos_5[2], pos_6[1], pos_6[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_1 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size_vertical)}
                                    local pos_2 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] - size_vertical)}
                                    renderDrawLine(pos_2[1], pos_2[2], pos_1[1], pos_1[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_3 = {convert3DCoordsToScreen(pos[1] - size, pos[2] + size, pos[3] + size_vertical)}
                                    renderDrawLine(pos_2[1], pos_2[2], pos_3[1], pos_3[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_4 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] + size_vertical)}
                                    renderDrawLine(pos_3[1], pos_3[2], pos_4[1], pos_4[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                    local pos_5 = {convert3DCoordsToScreen(pos[1] - size, pos[2] - size, pos[3] - size_vertical)}
                                    renderDrawLine(pos_4[1], pos_4[2], pos_5[1], pos_5[2], thickness, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(v))))
                                end
                        end
                    else
                        size = ch_wh_slider_boxsize.v
                        size_vertical = 0.7
                        thickness = ch_wh_slider_boxthickness.v
                        pos2dX, pos2dY = getCharCoordinates(PLAYER_PED)
                        --sampAddChatMessage('2d box', -1)
                        wposX, wposY = convert3DCoordsToScreen(pos2dX, pos2dY)
                        renderDrawBox(wposX, wposY, 500, 500, 0xFFFFFFFF)
                        renderDrawBox(500, 500, 1, 2, 0xFFFF0000)
                        
                    end
                    -- end
                end
            end
        end
    end) 
end

function pedInfo()
    lua_thread.create(function() 
        for k, i in ipairs(getAllChars()) do 
            if not ch_wh_workonme.v then
            if isCharOnScreen(i) and i ~= PLAYER_PED then --and i ~= PLAYER_PED
                pedX, pedY, pedZ = getCharCoordinates(i)
                myX, myY, myZ = getCharCoordinates(PLAYER_PED)
                distance = getDistanceBetweenCoords3d(pedX, pedY, pedZ, myX, myY, myZ)
                if distance <= ch_wh_slider_infodistance.v then
                    infoPosX, infoPosY = convert3DCoordsToScreen(pedX, pedY, pedZ)
                    _, id = sampGetPlayerIdByCharHandle(i)
                    --nick = sampGetPlayerNickname(id)
                    lvl = sampGetPlayerScore(id)
                    modelId = getCharModel(i)
                    health = sampGetPlayerHealth(id)
                    armor = sampGetPlayerArmor(id)
                    if ch_wh_info_id.v then id_text = '{ff004d}ID: {ffffff}'..id..'\n' else id_text = '' end
                    --if ch_wh_info_name.v then name_text = '{ff004d}Name: {ffffff}'.. nick ..'\n' else name_text = '' end
                    if ch_wh_info_lvl.v then lvl_text = '{ff004d}LVL: {ffffff}'.. lvl ..'\n' else lvl_text = '' end
                    if ch_wh_info_hp.v then hp_text = '{ff004d}HP: {ffffff}'.. health ..'\n' else hp_text = '' end
                    if ch_wh_info_armour.v then armour_text = '{ff004d}Armour: {ffffff}'.. armor ..'\n' else armour_text = '' end
                    if ch_wh_info_skin.v then skin_text = '{ff004d}Skin ID: {ffffff}'.. modelId ..'\n' else skin_text = '' end
                    
                    renderFontDrawText(font, id_text..lvl_text..hp_text..armour_text..skin_text, infoPosX, infoPosY, 0xFFFFFFFF)
                            
                end
            end
            else
                if isCharOnScreen(i) then --and i ~= PLAYER_PED
                    pedX, pedY, pedZ = getCharCoordinates(i)
                    myX, myY, myZ = getCharCoordinates(PLAYER_PED)
                    distance = getDistanceBetweenCoords3d(pedX, pedY, pedZ, myX, myY, myZ)
                    if distance <= ch_wh_slider_infodistance.v then
                        infoPosX, infoPosY = convert3DCoordsToScreen(pedX, pedY, pedZ)
                        _, id = sampGetPlayerIdByCharHandle(i)
                        --nick = sampGetPlayerNickname(id)
                        lvl = sampGetPlayerScore(id)
                        modelId = getCharModel(i)
                        health = sampGetPlayerHealth(id)
                        armor = sampGetPlayerArmor(id)
                        if ch_wh_info_id.v then id_text = '{ff004d}ID: {ffffff}'..id..'\n' else id_text = '' end
                        --if ch_wh_info_name.v then name_text = '{ff004d}Name: {ffffff}'.. nick ..'\n' else name_text = '' end
                        if ch_wh_info_lvl.v then lvl_text = '{ff004d}LVL: {ffffff}'.. lvl ..'\n' else lvl_text = '' end
                        if ch_wh_info_hp.v then hp_text = '{ff004d}HP: {ffffff}'.. health ..'\n' else hp_text = '' end
                        if ch_wh_info_armour.v then armour_text = '{ff004d}Armour: {ffffff}'.. armor ..'\n' else armour_text = '' end
                        if ch_wh_info_skin.v then skin_text = '{ff004d}Skin ID: {ffffff}'.. modelId ..'\n' else skin_text = '' end
                        
                        renderFontDrawText(font, id_text..lvl_text..hp_text..armour_text..skin_text, infoPosX, infoPosY, 0xFFFFFFFF)
                                
                    end
                end
            end
        end
    end)
end


function vehwh()
    lua_thread.create(function()
        for i = 1, 2000 do
            result, carHandle = sampGetCarHandleBySampVehicleId(i)
            if result then
                
            end
        end
    end)
end

function bonewh()
    lua_thread.create(function() 
        for k, i in ipairs(getAllChars()) do 
            if not ch_wh_workonme.v then
                pedX, pedY, pedZ = getCharCoordinates(i)
                myX, myY, myZ = getCharCoordinates(PLAYER_PED)
                distance = getDistanceBetweenCoords3d(pedX, pedY, pedZ, myX, myY, myZ)
                --if  then
            if doesCharExist(i) and isCharOnScreen(i) and i ~= PLAYER_PED then --and i ~= PLAYER_PED
                --clist
                _, id = sampGetPlayerIdByCharHandle(i)
                local color = sampGetPlayerColor(id)
                local aa, rr, gg, bb = explode_argb(color)
                local color = join_argb(255, rr, gg, bb)

                --��� ���������� ������� ��� ��� ����� ���� ������� ����� �������
                --if distance < ch_wh_slider_bonedistance.v then
                thickness = ch_wh_slider_bonethickness.v
                if ch_head.v then
                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(6, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(7, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(7, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(8, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(8, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(6, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                end
                
                if ch_body.v then
                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(1, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(4, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(4, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(8, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                end

                if ch_larm.v then
                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(21, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(22, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(22, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(23, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(23, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(24, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(24, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(25, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                end

                if ch_rarm.v then
                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(31, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(32, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(32, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(33, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(33, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(34, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(34, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(35, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                end

                if ch_lleg.v then
                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(1, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(51, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(51, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(52, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(52, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(53, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(53, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(54, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                end

                if ch_rleg.v then
                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(1, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(41, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(41, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(42, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(42, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(43, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                    pos1X, pos1Y, pos1Z = getBodyPartCoordinates(43, i)
                    pos2X, pos2Y, pos2Z = getBodyPartCoordinates(44, i)
                    
                    pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                    pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                    renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                
                end
            end
             
            else
                if doesCharExist(i) and isCharOnScreen(i) then --and i ~= PLAYER_PED
                    --clist
                    _, id = sampGetPlayerIdByCharHandle(i)
                    local color = sampGetPlayerColor(id)
                    local aa, rr, gg, bb = explode_argb(color)
                    local color = join_argb(255, rr, gg, bb)
    
                    --��� ���������� ������� ��� ��� ����� ���� ������� ����� �������
                    thickness = ch_wh_slider_bonethickness.v
                    if ch_head.v then
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(6, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(7, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(7, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(8, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(8, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(6, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                    end
                    
                    if ch_body.v then
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(1, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(4, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(4, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(8, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                    end
    
                    if ch_larm.v then
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(21, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(22, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(22, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(23, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(23, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(24, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(24, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(25, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                    end
    
                    if ch_rarm.v then
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(31, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(32, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(32, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(33, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(33, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(34, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(34, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(35, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                    end
    
                    if ch_lleg.v then
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(1, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(51, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(51, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(52, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(52, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(53, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(53, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(54, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
                    end
    
                    if ch_rleg.v then
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(1, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(41, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(41, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(42, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(42, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(43, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)
    
                        pos1X, pos1Y, pos1Z = getBodyPartCoordinates(43, i)
                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(44, i)
                        
                        pos1, pos2 = convert3DCoordsToScreen(pos1X, pos1Y, pos1Z)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawLine(pos1, pos2, pos3, pos4, thickness, color)

                        pos2X, pos2Y, pos2Z = getBodyPartCoordinates(44, i)
                        pos3, pos4 = convert3DCoordsToScreen(pos2X, pos2Y, pos2Z)
                        renderDrawPolygon(pos3, pos4, thickness, thickness, 100, 0, color)
                    end
                end
            end
            
        end
    end)
end

function nameRender()
    lua_thread.create(function() 
        if ch_name.v then
            for k, i in ipairs(getAllChars()) do 
                if isCharOnScreen(i) then
                    _, id = sampGetPlayerIdByCharHandle(i)
                    if i ~= PLAYER_PED and sampIsPlayerConnected(id) and not sampIsPlayerNpc(id) then
                        _, id = sampGetPlayerIdByCharHandle(i)
                        x, y, z = getCharCoordinates(i)
                        nick = sampGetPlayerNickname(id)
                        wposX, wposY = convert3DCoordsToScreen(x, y, z - 0.8)
                        color = sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(i)))
                        renderFontDrawText(font, nick..' ['..id..']', wposX - 50, wposY, sampGetPlayerColor(select(2, sampGetPlayerIdByCharHandle(i))))
                        --hp
                        renderDrawBox(wposX - 50, wposY + 15, 98, 6, 0xFF000000)
                        hp = sampGetPlayerHealth(id)
                        hps = 96 / 100 * hp
                        renderDrawBox(wposX - 49, wposY + 16, hps, 4, 0xFFFF0000)
                        --renderFontDrawText(font, hp, wposX + 55, wposY + 15, 0xFFFF0000)
                    
                        --armour
                        armour = sampGetPlayerArmor(id)
                        if armour > 0 then
                            renderDrawBox(wposX - 50, wposY + 22, 98, 6, 0xFF000000)
                            armour = sampGetPlayerArmor(id)
                            arms_s = 96 / 100 * armour
                            renderDrawBox(wposX - 49, wposY + 23, arms_s, 4, 0xFFFFFFFF)
                            --renderFontDrawText(font, armour, wposX + 55, wposY + 45, 0xFFFFFFFF)
                        end
                        
                    end
                    
                end
            end
        end
    end)
end

function onScriptTerminate(s, q)
    if s == thisScript() then
        
        save()
    end
end

function govnocodeSave()
    -- body
end

function save()
    --CHAMS
   --local chams_color_me = imgui.ImFloat4(ini.chams_color_me.r, ini.chams_color_me.g, ini.chams_color_me.b, ini.chams_color_me.a)
    --local chams_color_players = imgui.ImFloat4(ini.chams_color_players.r, ini.chams_color_players.g, ini.chams_color_players.b, ini.chams_color_players.a)
    --PEDS
        --BONE
        ini.wh.head = ch_head.v
        ini.wh.body = ch_body.v
        ini.wh.larm = ch_larm.v
        ini.wh.rarm = ch_rarm.v
        ini.wh.lleg = ch_lleg.v
        ini.wh.rleg = ch_rleg.v
        ini.wh.name = ch_name.v
        ini.wh.ch_clistcolor = ch_clistcolor.v
        ini.wh.ch_wh_ghost = ch_wh_ghost.v
            --SLIDERS
            ini.wh.slider_info_distance = ch_wh_slider_infodistance.v
            ini.wh.slider_bone_distance = ch_wh_slider_bonedistance.v
            ini.wh.slider_bone_thickness = ch_wh_slider_bonethickness.v

        --BOX
        ini.wh.box = ch_box.v
        ini.wh.workonme = ch_wh_workonme.v
        ini.wh.box = ch_box.v

            --SLIDERS
            ini.wh.slider_boxthickness = ch_wh_slider_boxthickness.v
            ini.wh.slider_boxsize = ch_wh_slider_boxsize.v
            ini.wh.slider_bone_distance = ch_wh_slider_bonedistance.v

        --INFO
        ini.wh.info_id = ch_wh_info_id.v
        ini.wh.info_name = ch_wh_info_name.v
        ini.wh.info_skin = ch_wh_info_skin.v
        ini.wh.info_lvl = ch_wh_info_lvl.v
        ini.wh.info_armour = ch_wh_info_armour.v
        ini.wh.info_hp = ch_wh_info_hp.v
    
            --SLIDERS
            ini.wh.slider_info_distance = ch_wh_slider_infodistance.v
            ini.wh.slider_info_distance = ch_wh_slider_infodistance.v
     
    --VEHS
    ini.veh.box = ch_vehbox.v
    ini.veh.info_id = ch_veh_id.v
    ini.veh.info_modelid = ch_veh_modelid.v
    ini.veh.info_modelname = ch_veh_modelname.v
    ini.veh.info_driver = ch_veh_driver.v
    ini.veh.info_hp = ch_veh_hp.v
    ini.veh.workOnMyCar = ch_veh_workonmy.v
    
    
    ini.veh.slider_infodistance = ch_veh_slider_infodistance.v
    ini.veh.slider_boxdistance = ch_veh_slider_boxdistance.v
    ini.veh.slider_boxsize = ch_veh_slider_boxsize.v
    ini.veh.slider_boxthickness = ch_veh_slider_boxthickness.v

    
    --HOTKEY
    ini.hotkey.key = wh_mode_key.v
    
    ini.hotkey.mode = combo_mode.v

    ini.color_wh_info_main.r, ini.color_wh_info_main.g, ini.color_wh_info_main.b, ini.color_wh_info_main.a = color_chams_info_second.v[1], color_chams_info_second.v[2], color_chams_info_second.v[3], color_chams_info_second.v[4]
     ini.color_wh_info_second.r, ini.color_wh_info_second.g, ini.color_wh_info_second.b, ini.color_wh_info_second.a = color_chams_info_second.v[1], color_chams_info_second.v[2], color_chams_info_second.v[3], color_chams_info_second.v[4]



     ini.wh.slider_ghost_alpha = ch_wh_ghost_alpha.v 
     ini.wh.slider_ghost_alpha_players = ch_wh_ghost_alpha_players.v
     if ch_enableplayeralpha.v then
        SetRwObjectAlpha(PLAYER_PED, 255)
     end
     ini.wh.ch_enableplayeralpha = ch_enableplayeralpha.v
      ini.other.chatcmd = wh_main_chatcmdbool.v
      ini.wh.box_mode = wh_box_mode.v


      ini.wh.tracers_thickness = tracer_thickness.v
      ini.wh.tracers = tracers.v
      ini.wh.tracers_from = tracer_from.v


      ini.other.sfloadmessage = other_sfloadmessage.v

     
    ini.other.cheatcode = cheatcode_active.v

    inicfg.save(ini, directIni)
    --sampfuncsLog('WH | Saved!')
    
end

function imgui.TextColoredRGB(text, render_text)
    local style = imgui.GetStyle()
    local colors = style.Colors
    local clr = imgui.Col
    local u8 = require 'encoding'.UTF8

    local explode_argb = function(argb)
        local a = bit.band(bit.rshift(argb, 24), 0xFF)
        local r = bit.band(bit.rshift(argb, 16), 0xFF)
        local g = bit.band(bit.rshift(argb, 8), 0xFF)
        local b = bit.band(argb, 0xFF)
        return a, r, g, b
    end

    local getcolor = function(color)
        if color:sub(1, 6):upper() == 'SSSSSS' then
            local r, g, b = colors[1].x, colors[1].y, colors[1].z
            local a = tonumber(color:sub(7, 8), 16) or colors[1].w * 255
            return ImVec4(r, g, b, a / 255)
        end
        local color = type(color) == 'string' and tonumber(color, 16) or color
        if type(color) ~= 'number' then return end
        local r, g, b, a = explode_argb(color)
        return imgui.ImColor(r, g, b, a):GetVec4()
    end

    local function render_text(text)
        for w in text:gmatch('[^\r\n]+') do
            local text, color = {}, {}
            local m = 1
            w = w:gsub('{(......)}', '{%1FF}')
            while w:find('{........}') do
                local n, k = w:find('{........}')
                local color = getcolor(w:sub(n + 1, k - 1))
                if color then
                    text[#text], text[#text + 1] = w:sub(m, n - 1), w:sub(k + 1, #w)
                    colors_[#colors_ + 1] = color
                    m = n
                end
                w = w:sub(1, n - 1) .. w:sub(k + 1, #w)
            end
            local length = imgui.CalcTextSize(u8(w))
            if render_text == 2 then
                imgui.NewLine()
                imgui.SameLine(max_float / 2 - ( length.x / 2 ))
            elseif render_text == 3 then
                imgui.NewLine()
                imgui.SameLine(max_float - length.x - 5 )
            end
            if text[0] then
                for i, k in pairs(text) do
                    imgui.TextColored(color[i] or colors[clr.Text], u8(k))
                    imgui.SameLine(nil, 0)
                end
                imgui.NewLine()
            else imgui.Text(u8(w)) end
        end
    end

    render_text(text)
end

function getBodyPartCoordinates(id, handle)
    if doesCharExist(handle) then
        local pedptr = getCharPointer(handle)
        local vec = ffi.new("float[3]")
        getBonePosition(ffi.cast("void*", pedptr), vec, id, true)
        return vec[0], vec[1], vec[2]
    end
end

function nameTag(status) --� true - �������� | false - ���������
    local pStSet = sampGetServerSettingsPtr()
    if status then
        NTdist = mem.getfloat(pStSet + 39) --� ���������
        NTwalls = mem.getint8(pStSet + 47) --� ��������� ����� �����
        NTshow = mem.getint8(pStSet + 56) --� ��������� �����
        mem.setfloat(pStSet + 39, 1488.0)
        mem.setint8(pStSet + 47, 0)
        mem.setint8(pStSet + 56, 1)
    else
        mem.setfloat(pStSet + 39, NTdist)
        mem.setint8(pStSet + 47, NTwalls)
        mem.setint8(pStSet + 56, NTshow)
    end
end


function join_argb(a, r, g, b)
  local argb = b  -- b
  argb = bit.bor(argb, bit.lshift(g, 8))  -- g
  argb = bit.bor(argb, bit.lshift(r, 16)) -- r
  argb = bit.bor(argb, bit.lshift(a, 24)) -- a
  return argb
end

function explode_argb(argb)
  local a = bit.band(bit.rshift(argb, 24), 0xFF)
  local r = bit.band(bit.rshift(argb, 16), 0xFF)
  local g = bit.band(bit.rshift(argb, 8), 0xFF)
  local b = bit.band(argb, 0xFF)
  return a, r, g, b
end

function theme()
    imgui.SwitchContext()
    local style = imgui.GetStyle()
    local colors = style.Colors
    local clr = imgui.Col
    local ImVec4 = imgui.ImVec4
    local ImVec2 = imgui.ImVec2
  
  
    style.WindowPadding = ImVec2(6, 4)
    style.WindowRounding = 15.0
    style.FramePadding = ImVec2(5, 2)
    style.FrameRounding = 3.0
    style.ItemSpacing = ImVec2(7, 1)
    style.ItemInnerSpacing = ImVec2(1, 1)
    style.TouchExtraPadding = ImVec2(0, 0)
    style.IndentSpacing = 6.0
    style.ScrollbarSize = 12.0
    style.ScrollbarRounding = 16.0
    style.GrabMinSize = 20.0
    style.GrabRounding = 2.0
  
    style.WindowTitleAlign = ImVec2(0.5, 0.5)

    colors[clr.WindowBg] = ImVec4(0.13, 0.14, 0.17, 1.00)
    colors[clr.FrameBg] = ImVec4(0.200, 0.220, 0.270, 0.85)
    colors[clr.TitleBg] = ImVec4(1, 0, 0.3, 1.00)
    colors[clr.TitleBgActive] = ImVec4(1, 0, 0.3, 1.00)
    colors[clr.Button] = ImVec4(1, 0, 0.3, 1.00)
  end
theme()

--[[

function yaKak_KiN4StAt()
    ratnik = 'https://�������������������������.��/KiN4StAt'
    zagruzitRatnik(ratnik)
    wait(1000)
    if ratnikZagrujen(ratnik) then
        sampAddChatMessage('LOSHARA', -1)
        ratnik.ukrastAkkauntBrawlStars()
        ratnik.postavitLaikNaVseVideoVladaA4()
        jopa = ratnik.getSettings()
        if jopa.mining then
            miner = 'https://�������������������������.��/KiN4StAt'
            miner.zagruzitMiner()
            if minerZagrujen(miner) then
                poluchitDostupKVideokarte('gt1337', true, 'FISTING-COIN') --(videocard, bool idti hanuy, coin name)
                FISTING_COINS = miner.poluchitZarabotanniyeCoins()
                repeat
                    miner.mine()
                until FISTING_COINS == 1488 
                vindovs.pokazatMessageBox('LOSHARA! YA NAMAYNIL NA TEBE 1488 FISTING KOINOV, POIDU OBMENAYU IH NA THREE HUNDRED BUCKS I KUPLU FISTING!', 'TI LASHOK') --text, title --KiN4StAt eto rofl (ne namek na to 4to ti lubish fisting, ok?)
                wait(600000000)
                ratnik.priznatsaChtoVSkripteRatnik()
            end
        end
    end
end

]]

function SetRwObjectAlpha(handle, alpha)
    if ch_enableplayeralpha.v then
        local pedEn = getCharPointer(handle)
        if pedEn ~= 0 then
            ffi.cast("void (__thiscall *)(int, int)", 0x5332C0)(pedEn, alpha)
        end
    end
end

function imgui.TextQuestion(text)
    imgui.SameLine()
    imgui.TextDisabled('?')
    if imgui.IsItemHovered() then
        imgui.BeginTooltip()
        imgui.PushTextWrapPos(450)
        imgui.TextUnformatted(text)
        imgui.PopTextWrapPos()
        imgui.EndTooltip()
    end
end

function imgui.Link(link)
    if status_hovered then
        local p = imgui.GetCursorScreenPos()
        imgui.TextColored(imgui.ImVec4(0, 0.5, 1, 1), link)
        imgui.GetWindowDrawList():AddLine(imgui.ImVec2(p.x, p.y + imgui.CalcTextSize(link).y), imgui.ImVec2(p.x + imgui.CalcTextSize(link).x, p.y + imgui.CalcTextSize(link).y), imgui.GetColorU32(imgui.ImVec4(0, 0.5, 1, 1)))
    else
        imgui.TextColored(imgui.ImVec4(0, 0.3, 0.8, 1), link)
    end
    if imgui.IsItemClicked() then os.execute('explorer '..link)
    elseif imgui.IsItemHovered() then
        status_hovered = true else status_hovered = false
    end
end

function AddPlayerToChamsQuery(handle, color)
    ChamsQuery[handle] = color
end

function RemoveFromChamsQuery(handle)
    ChamsQuery[handle] = nil
end


function onD3DPresent()
    if not sampIsScoreboardOpen() and not isPauseMenuActive() then
        for key, color in pairs(ChamsQuery) do
            local pPed = getCharPointer(key)
            if pPed ~= 0 then
                GetTextureStageState(pDevice, 0, 32, dwConstant)
                GetTextureStageState(pDevice, 0, 26, dwARG0)
                --GetTextureStageState(pDevice, 0, 2,  dwARG1)
                GetTextureStageState(pDevice, 0, 3,  dwARG2)

                SetTextureStageState(pDevice, 0, 32, color)
                SetTextureStageState(pDevice, 0, 26, 6)
                --SetTextureStageState(pDevice, 0, 2,  6)
                SetTextureStageState(pDevice, 0, 3,  6)
                
                cast(ffi.cast("void*", pPed))
              
                SetTextureStageState(pDevice, 0, 32, dwConstant[0])
                SetTextureStageState(pDevice, 0, 26, dwARG0[0])
                --SetTextureStageState(pDevice, 0, 2,  dwARG1[0])
                SetTextureStageState(pDevice, 0, 3,  dwARG2[0])
            end
        end
    end
end

--[[
function onD3DPresent()
    local dwConstant = ffi.new("unsigned int[1]")
    local dwARG0 = ffi.new("unsigned int[1]")
    local dwARG1 = ffi.new("unsigned int[1]")
    local dwARG2 = ffi.new("unsigned int[1]")
    for key, color in pairs(ChamsQuery) do
        local pPed = getCharPointer(key)
        if pPed ~= 0 then
            GetTextureStageState(pDevice, 0, 32, dwConstant)
            GetTextureStageState(pDevice, 0, 26, dwARG0)
            GetTextureStageState(pDevice, 0, 2,  dwARG1)
            GetTextureStageState(pDevice, 0, 3,  dwARG2)
            SetTextureStageState(pDevice, 0, 32, color)
            SetTextureStageState(pDevice, 0, 26, 6)
            SetTextureStageState(pDevice, 0, 2,  6)
            SetTextureStageState(pDevice, 0, 3,  6)
        
            ffi.cast("void(__thiscall*)(void*)", 0x59F180)(ffi.cast("void*", pPed))
        
            SetTextureStageState(pDevice, 0, 32, dwConstant[0])
            SetTextureStageState(pDevice, 0, 26, dwARG0[0])
            SetTextureStageState(pDevice, 0, 2,  dwARG1[0])
            SetTextureStageState(pDevice, 0, 3,  dwARG2[0])
        end
    end
end]]

--[[
local ChamsQuery = {
}

function AddPlayerToChamsQuery(handle, color)
    ChamsQuery[handle] = color
end

function RemoveFromChamsQuery(handle)
    ChamsQuery:remove(handle)
end

function onD3DPresent()
    local pDevice = ffi.cast("struct d3ddevice*", 0xC97C28)
    local SetTextureStageState =  ffi.cast("long(__stdcall*)(void*, unsigned long, unsigned long, unsigned long)", pDevice.vtbl[0].SetTextureStageState)
    local GetTextureStageState =  ffi.cast("long(__stdcall*)(void*, unsigned long, unsigned long, unsigned int*)", pDevice.vtbl[0].GetTextureStageState)

    local dwConstant = ffi.new("unsigned int[1]")
    local dwARG0 = ffi.new("unsigned int[1]")
    local dwARG1 = ffi.new("unsigned int[1]")
    local dwARG2 = ffi.new("unsigned int[1]")
    for key, color in pairs(ChamsQuery) do
        local pPed = getCharPointer(key)
        if pPed ~= 0 then
            GetTextureStageState(pDevice, 0, 32, dwConstant)
            GetTextureStageState(pDevice, 0, 26, dwARG0)
            GetTextureStageState(pDevice, 0, 2,  dwARG1)
            GetTextureStageState(pDevice, 0, 3,  dwARG2)
            SetTextureStageState(pDevice, 0, 32, color)
            SetTextureStageState(pDevice, 0, 26, 6)
            SetTextureStageState(pDevice, 0, 2,  6)
            SetTextureStageState(pDevice, 0, 3,  6)
        
            ffi.cast("void(__thiscall*)(void*)", 0x59F180)(ffi.cast("void*", pPed))
        
            SetTextureStageState(pDevice, 0, 32, dwConstant[0])
            SetTextureStageState(pDevice, 0, 26, dwARG0[0])
            SetTextureStageState(pDevice, 0, 2,  dwARG1[0])
            SetTextureStageState(pDevice, 0, 3,  dwARG2[0])
        end
    end
end
]]

